import json
import boto3
import os
import re
import urllib.parse
import time
import snowflake.connector

# AWS clients
ssm_client = boto3.client('ssm')
stepfunctions = boto3.client('stepfunctions')
s3 = boto3.client('s3')

# Env variables
FILE_PATTERN = r"(.+)_(\d{14})\.csv\.gz"
SECRET_NAME = os.environ['SNOWFLAKE_SECRET_NAME']
STEP_FUNCTION_ARN = os.environ['STEP_FUNCTION_ARN']  # Step Function ARN
DATABASE = os.environ['DATABASE']
SCHEMA = os.environ['SCHEMA']
WAREHOUSE = os.environ['WAREHOUSE']

# -------------------------------
# Snowflake connection
# -------------------------------
def get_snowflake_connection():
    response = ssm_client.get_parameter(Name=SECRET_NAME, WithDecryption=True)
    creds = json.loads(response['Parameter']['Value'])
    conn = snowflake.connector.connect(
        user=creds['sfUser'],
        password=creds['sfPassword'],
        account=creds['sfURL'],
        warehouse=WAREHOUSE,
        database=DATABASE,
        schema=SCHEMA
    )
    return conn

# -------------------------------
# Check if file is fully uploaded
# -------------------------------
def is_file_stable(bucket, key, wait_seconds=10):
    first_size = s3.head_object(Bucket=bucket, Key=key)['ContentLength']
    time.sleep(wait_seconds)
    second_size = s3.head_object(Bucket=bucket, Key=key)['ContentLength']
    return first_size == second_size

# -------------------------------
# Parse filename
# -------------------------------
def parse_filename(filename):
    match = re.search(FILE_PATTERN, filename)
    if not match:
        return None
    prefix = match.group(1)
    timestamp = match.group(2)
    file_date = timestamp[:8]
    return prefix, file_date

# -------------------------------
# Check duplicate
# -------------------------------
def is_duplicate(cursor, filename):
    sql = f"""
    SELECT COUNT(*) FROM {DATABASE}.{SCHEMA}.FILE_ARRIVAL_MANIFEST
    WHERE FILE_NAME=%s
    """
    cursor.execute(sql, (filename,))
    return cursor.fetchone()[0] > 0

# -------------------------------
# Insert manifest record
# -------------------------------
def insert_manifest(cursor, filename, prefix, file_date, key, size):
    sql = f"""
    INSERT INTO {DATABASE}.{SCHEMA}.FILE_ARRIVAL_MANIFEST
    (FILE_NAME, FILE_PREFIX, FILE_DATE, S3_PATH, FILE_SIZE, ARRIVAL_TS, STATUS, PIPELINE_TRIGGERED, PIPELINE_STATUS)
    VALUES (%s, %s, TO_DATE(%s,'YYYYMMDD'), %s, %s, CURRENT_TIMESTAMP, 'ARRIVED', FALSE, 'PENDING')
    """
    cursor.execute(sql, (filename, prefix, file_date, key, size))

# -------------------------------
# Get expected file count from pipeline config
# -------------------------------
def get_expected_file_count(cursor):
    sql = f"""
    SELECT SUM(EXPECTED_DAILY_FILES)
    FROM {DATABASE}.{SCHEMA}.PIPELINE_CONFIG
    WHERE ACTIVE_FLAG='Y'
    """
    cursor.execute(sql)
    return cursor.fetchone()[0]

# -------------------------------
# Get received file count for a date
# -------------------------------
def get_received_file_count(cursor, file_date):
    sql = f"""
    SELECT COUNT(DISTINCT FILE_PREFIX)
    FROM {DATABASE}.{SCHEMA}.FILE_ARRIVAL_MANIFEST
    WHERE FILE_DATE=TO_DATE(%s,'YYYYMMDD')
    """
    cursor.execute(sql, (file_date,))
    return cursor.fetchone()[0]

# -------------------------------
# Get pipeline status
# -------------------------------
def get_pipeline_status(cursor, file_date):
    sql = f"""
    SELECT DISTINCT PIPELINE_STATUS
    FROM {DATABASE}.{SCHEMA}.FILE_ARRIVAL_MANIFEST
    WHERE FILE_DATE=TO_DATE(%s,'YYYYMMDD')
    """
    cursor.execute(sql, (file_date,))
    res = cursor.fetchone()
    return res[0] if res else 'PENDING'

# -------------------------------
# Mark pipeline triggered
# -------------------------------
def mark_pipeline_status(cursor, file_date, status):
    sql = f"""
    UPDATE {DATABASE}.{SCHEMA}.FILE_ARRIVAL_MANIFEST
    SET PIPELINE_TRIGGERED = %s,
        PIPELINE_STATUS = %s
    WHERE FILE_DATE=TO_DATE(%s,'YYYYMMDD')
    """
    cursor.execute(sql, (status=='TRIGGERED', status, file_date))

# -------------------------------
# Trigger Step Function
# -------------------------------
def trigger_pipeline(file_date):
    stepfunctions.start_execution(
        stateMachineArn=STEP_FUNCTION_ARN,
        input=json.dumps({"file_date": file_date})
    )

# -------------------------------
# Lambda handler
# -------------------------------
def lambda_handler(event, context):
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(record['s3']['object']['key'])
    filename = key.split("/")[-1]

    print(f"File received: {filename}")

    if not is_file_stable(bucket, key):
        print(f"File still uploading: {filename}")
        return {"status": "upload_in_progress", "file": filename}

    size = record['s3']['object']['size']
    parsed = parse_filename(filename)
    if not parsed:
        print(f"File pattern mismatch: {filename}")
        return {"status": "skipped", "file": filename}

    prefix, file_date = parsed
    print(f"Processing prefix: {prefix}, File date: {file_date}")

    conn = get_snowflake_connection()
    cursor = conn.cursor()

    try:
        if is_duplicate(cursor, filename):
            print(f"Duplicate file ignored: {filename}")
            return {"status": "duplicate", "file": filename}

        insert_manifest(cursor, filename, prefix, file_date, key, size)
        conn.commit()
        print("File inserted into manifest")

        expected_files = get_expected_file_count(cursor)
        received_files = get_received_file_count(cursor, file_date)
        pipeline_status = get_pipeline_status(cursor, file_date)

        print(f"Expected files: {expected_files}, Received files: {received_files}, Pipeline status: {pipeline_status}")

        # Trigger only if all files arrived and pipeline not SUCCESS
        if received_files >= expected_files and pipeline_status != 'SUCCESS':
            print("All files arrived. Triggering pipeline...")
            mark_pipeline_status(cursor, file_date, 'TRIGGERED')
            conn.commit()
            trigger_pipeline(file_date)
        else:
            print("Waiting for remaining files or pipeline already SUCCESS")

    except Exception as e:
        print(f"Error processing {filename}: {str(e)}")
        raise e
    finally:
        cursor.close()
        conn.close()

    return {"status": "processed", "file": filename}