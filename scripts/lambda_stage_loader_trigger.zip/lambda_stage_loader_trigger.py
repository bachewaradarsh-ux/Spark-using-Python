import json
import boto3
import os
import re
import snowflake.connector

# Clients
secrets_client = boto3.client('secretsmanager')
stepfunctions = boto3.client('stepfunctions')

# Environment variables
FILE_PATTERN = r"(telecom_data_[a-z])_(\d{14})\.csv\.gz"
EXPECTED_FILES = int(os.environ['EXPECTED_FILES'])
SECRET_NAME = os.environ['SNOWFLAKE_SECRET_NAME']
STEP_FUNCTION_ARN = os.environ['STEP_FUNCTION_ARN']
DATABASE = os.environ['DATABASE']
SCHEMA = os.environ['SCHEMA']
WAREHOUSE = os.environ['WAREHOUSE']


def get_snowflake_connection():
    secret = secrets_client.get_secret_value(SecretId=SECRET_NAME)
    creds = json.loads(secret['SecretString'])

    conn = snowflake.connector.connect(
        user=creds['sfUser'],
        password=creds['sfPassword'],
        account=creds['sfURL'],
        warehouse=WAREHOUSE,
        database=DATABASE,
        schema=SCHEMA
    )
    return conn


def parse_filename(filename):
    match = re.search(FILE_PATTERN, filename)
    if not match:
        return None
    prefix = match.group(1)
    timestamp = match.group(2)
    file_date = timestamp[:8]  # YYYYMMDD
    return prefix, file_date


def insert_manifest(cursor, filename, prefix, file_date, key, size):
    sql = """
    INSERT INTO FILE_ARRIVAL_MANIFEST
    (FILE_NAME, FILE_PREFIX, FILE_DATE, S3_PATH, FILE_SIZE, STATUS)
    VALUES (%s, %s, %s, %s, %s, 'ARRIVED')
    """
    cursor.execute(sql, (filename, prefix, file_date, key, size))


def get_file_count(cursor, file_date):
    sql = """
    SELECT COUNT(DISTINCT FILE_PREFIX)
    FROM FILE_ARRIVAL_MANIFEST
    WHERE FILE_DATE=%s
    """
    cursor.execute(sql, (file_date,))
    return cursor.fetchone()[0]


def try_trigger_pipeline(cursor, file_date):
    """
    Atomic lock to ensure Step Function triggers only once per file_date
    """
    update_sql = """
    UPDATE FILE_ARRIVAL_MANIFEST
    SET PIPELINE_TRIGGERED = TRUE
    WHERE FILE_DATE = %s
      AND PIPELINE_TRIGGERED = FALSE
    """
    cursor.execute(update_sql, (file_date,))
    updated_rows = cursor.rowcount
    return updated_rows > 0  # True if Lambda won the trigger lock


def trigger_pipeline(file_date):
    stepfunctions.start_execution(
        stateMachineArn=STEP_FUNCTION_ARN,
        input=json.dumps({"file_date": file_date})
    )


def lambda_handler(event, context):
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = record['s3']['object']['key']
    size = record['s3']['object']['size']
    filename = key.split("/")[-1]

    parsed = parse_filename(filename)
    if not parsed:
        print(f"File pattern mismatch: {filename}")
        return {"status": "skipped", "file": filename}

    prefix, file_date = parsed

    conn = get_snowflake_connection()
    cursor = conn.cursor()

    try:
        # Insert manifest
        insert_manifest(cursor, filename, prefix, file_date, key, size)
        conn.commit()

        # Count files for this date
        file_count = get_file_count(cursor, file_date)
        print(f"Files received for {file_date}: {file_count}")

        # Trigger Step Function if all files arrived
        if file_count >= EXPECTED_FILES:
            if try_trigger_pipeline(cursor, file_date):
                print(f"Triggering Step Function for {file_date}")
                trigger_pipeline(file_date)
            else:
                print(f"Step Function already triggered for {file_date}")

    except Exception as e:
        print(f"Error processing file {filename}: {str(e)}")

    finally:
        cursor.close()
        conn.close()

    return {"status": "processed", "file": filename}