import logging
import boto3
import json
from datetime import datetime
from pyspark.sql import SparkSession

class ProjectLogger:
    def __init__(self, job_name, bucket_name="project-data-adarshpractice"):
        self.job_name = job_name
        self.bucket_name = bucket_name
        self.session_ts = datetime.now().strftime("%Y%m%d%H%M%S")
        self.s3 = boto3.client("s3")

        # Console logging (still goes to CloudWatch automatically in Glue/EMR)
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        self.logger = logging.getLogger(job_name)

    def _s3_key(self):
        # Partitioned path for audit-friendly queries
        return f"telekom_project/logs/{self.job_name}/year={datetime.now().year}/month={datetime.now().month}/day={datetime.now().day}/{self.job_name}_{self.session_ts}.json"

    def log(self, level, message, extra=None):
        entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "level": level,
            "job_name": self.job_name,
            "message": message,
            "extra": extra or {}
        }

        # Console logging
        if level == "INFO":
            self.logger.info(message)
        elif level == "WARN":
            self.logger.warning(message)
        elif level == "ERROR":
            self.logger.error(message)
        elif level == "DEBUG":
            self.logger.debug(message)
            
    def capture_spark_metadata(self, spark):
        app_id = spark.sparkContext.applicationId
        master = spark.sparkContext.master
        conf = dict(spark.sparkContext.getConf().getAll())
        event_log_dir = spark.sparkContext.getConf().get("spark.eventLog.dir", None)

        self.log("INFO", "Spark Metadata", {
            "app_id": app_id,
            "master": master,
            "conf": conf,
            "event_log_dir": event_log_dir
        })

        # Stream log entry immediately to S3
        self.s3.put_object(
            Bucket=self.bucket_name,
            Key=self._s3_key(),
            Body=json.dumps(entry) + "\n"
        )