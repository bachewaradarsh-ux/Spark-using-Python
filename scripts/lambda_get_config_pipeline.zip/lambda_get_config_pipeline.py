import json
import boto3
import os
import snowflake.connector

ssm_client = boto3.client('ssm')

SECRET_NAME = os.environ['SNOWFLAKE_SECRET_NAME']
DATABASE = os.environ['DATABASE']
SCHEMA = os.environ['SCHEMA']
WAREHOUSE = os.environ['WAREHOUSE']


def get_connection():

    response = ssm_client.get_parameter(
        Name=SECRET_NAME,
        WithDecryption=True
    )

    creds = json.loads(response['Parameter']['Value'])

    conn = snowflake.connector.connect(
        user=creds['sfUser'],
        password=creds['sfPassword'],
        account=creds['sfURL'],
        warehouse=WAREHOUSE,
        database=DATABASE,
        schema=SCHEMA
    )

    return conn


def lambda_handler(event, context):

    file_date = event["file_date"]

    conn = get_connection()
    cursor = conn.cursor()

    sql = f"""
    SELECT
        FILE_PREFIX,
        STAGE_TABLE,
        LOAD_GROUP
    FROM {DATABASE}.{SCHEMA}.PIPELINE_CONFIG
    WHERE ACTIVE_FLAG='Y'
    ORDER BY LOAD_GROUP
    """

    cursor.execute(sql)

    rows = cursor.fetchall()

    groups = {}

    for r in rows:

        prefix = r[0]
        stage_table = r[1]
        group = r[2]

        if group not in groups:
            groups[group] = []

        groups[group].append({
            "prefix": prefix,
            "stage_table": stage_table
        })

    result = []

    for g in groups:
        result.append({
            "group": g,
            "files": groups[g]
        })

    cursor.close()
    conn.close()

    return {
        "file_date": file_date,
        "groups": result
    }